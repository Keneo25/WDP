#include <iostream>

using namespace std;

int foo(int a)
{
	if (a == 0 || a == 1)
		return 2;
	return foo(a - 2)+1;
}

int main()
{
	int a = 7; //a=
	int b = (a += 6); // a=  , b=
	int c = (b *= 2) / 3; // a=  , b=  , c=
	b = foo(a);  // a=  , b=  , c=
	c = ++b;  // a=  , b=  , c=
	return 0;
}