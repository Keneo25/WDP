#include <iostream>

using namespace std;

int main()
{
	int tab[5] = { -3,4,-2,8,9 };
	int a = tab[2]; //a=
	int b = (a += 6); // a=  , b=
	int c = (b *= 2) / 3; // a=  , b=  , c=
	b = c ^ a;  // a=  , b=  , c=
	c = ++b;  // a=  , b=  , c=
	return 0;
}